#!/usr/bin/env python3
"""
evaluar_politica.py — Motor de politica de gobernanza (Actividad 2, LSCA2314)

Lee politica.yaml y los reportes de una ejecucion, y decide si la entrega
se autoriza o se bloquea. La logica de decision vive en la politica, no
aqui: este motor no conoce umbrales, solo sabe COMO aplicarlos.
"""

import argparse
import json
import sys
from datetime import date
from pathlib import Path

try:
    import yaml
except ImportError:
    print("Falta PyYAML. Instalalo con: pip install pyyaml", file=sys.stderr)
    sys.exit(2)


def contar_secretos(carpeta: Path) -> int:
    """TODO 1: devuelve cuantos hallazgos trae gitleaks.json."""
    ruta = carpeta / "gitleaks.json"
    datos = json.loads(ruta.read_text(encoding="utf-8"))
    return len(datos)


def contar_infraestructura(carpeta: Path) -> int:
    """TODO 2: devuelve cuantos checks fallaron segun checkov.json."""
    ruta = carpeta / "checkov.json"
    datos = json.loads(ruta.read_text(encoding="utf-8"))
    return datos["summary"]["failed"]


def contar_semgrep(carpeta: Path, severidad: str) -> int:
    """TODO 3: devuelve cuantos hallazgos de esa severidad trae semgrep.json."""
    ruta = carpeta / "semgrep.json"
    datos = json.loads(ruta.read_text(encoding="utf-8"))
    return sum(
        1
        for r in datos.get("results", [])
        if r.get("extra", {}).get("severity") == severidad
    )


def contar_bandit(carpeta: Path, severidad: str) -> int:
    """TODO 4: devuelve cuantos hallazgos de esa severidad trae bandit.json."""
    ruta = carpeta / "bandit.json"
    datos = json.loads(ruta.read_text(encoding="utf-8"))
    return sum(
        1 for r in datos.get("results", []) if r.get("issue_severity") == severidad
    )


def excepciones_vigentes(politica: dict, hoy: date) -> dict:
    """
    TODO 5: devuelve cuantas excepciones VIGENTES tiene cada control.
    Una excepcion con fecha 'caduca' anterior a hoy ya no vale.
    Una excepcion sin 'caduca' se trata como permanente (vigente siempre) —
    aunque la politica de esta organizacion exige fecha en toda excepcion
    (ver documento de gobernanza).
    """
    conteo: dict = {}
    for exc in politica.get("excepciones") or []:
        control = exc.get("control")
        caduca_str = exc.get("caduca")
        vigente = True
        if caduca_str:
            vigente = date.fromisoformat(str(caduca_str)) >= hoy
        if vigente and control:
            conteo[control] = conteo.get(control, 0) + 1
    return conteo


_LECTORES = {
    "gitleaks": lambda carpeta, cfg: contar_secretos(carpeta),
    "checkov": lambda carpeta, cfg: contar_infraestructura(carpeta),
    "semgrep": lambda carpeta, cfg: contar_semgrep(carpeta, cfg.get("severidad")),
    "bandit": lambda carpeta, cfg: contar_bandit(carpeta, cfg.get("severidad")),
}


def evaluar(politica: dict, carpeta: Path, hoy: date) -> dict:
    """
    TODO 6: recorre los controles de la politica, obtiene el valor de cada uno,
    descuenta las excepciones vigentes, compara contra el maximo, y arma el
    diccionario del contrato.

    Regla 1: accion "informa" nunca bloquea.
    Regla 2: accion "bloquea" detiene la entrega si el valor (tras excepciones)
             supera el maximo.
    Regla 3: excepciones vigentes descuentan; las caducadas no.
    Regla 4: un control sin reporte es un error de ejecucion. Decision de esta
             organizacion: un reporte faltante o corrupto SIEMPRE bloquea,
             sin importar la accion configurada — no se puede autorizar una
             entrega que no se pudo verificar.
    """
    descuentos = excepciones_vigentes(politica, hoy)
    controles_out = []
    bloqueantes = []

    for nombre, cfg in (politica.get("controles") or {}).items():
        herramienta = cfg.get("herramienta")
        maximo = cfg.get("maximo", 0)
        accion = cfg.get("accion", "bloquea")
        lector = _LECTORES.get(herramienta)

        try:
            if lector is None:
                raise ValueError(f"herramienta desconocida: {herramienta}")
            valor = lector(carpeta, cfg)
        except (FileNotFoundError, json.JSONDecodeError, KeyError, ValueError):
            controles_out.append(
                {
                    "nombre": nombre,
                    "valor": None,
                    "maximo": maximo,
                    "accion": accion,
                    "excede": True,
                    "error": "reporte_faltante_o_invalido",
                }
            )
            bloqueantes.append(nombre)
            continue

        descuento = descuentos.get(nombre, 0)
        valor_efectivo = max(0, valor - descuento)
        excede = valor_efectivo > maximo

        controles_out.append(
            {
                "nombre": nombre,
                "valor": valor,
                "maximo": maximo,
                "accion": accion,
                "excede": excede,
                "descuento_excepciones": descuento,
            }
        )

        if excede and accion == "bloquea":
            bloqueantes.append(nombre)

    return {
        "decision": "BLOQUEADA" if bloqueantes else "AUTORIZADA",
        "politica_version": politica.get("version", "desconocida"),
        "controles": controles_out,
        "bloqueantes": bloqueantes,
    }


def main():
    parser = argparse.ArgumentParser(description="Motor de politica (Actividad 2)")
    parser.add_argument("politica", help="Ruta al archivo politica.yaml")
    parser.add_argument("evidencia", help="Carpeta con los reportes JSON")
    parser.add_argument("--json", help="Ruta opcional para guardar el resultado")
    parser.add_argument("--hoy", help="Fecha de referencia AAAA-MM-DD (para pruebas)")
    args = parser.parse_args()

    ruta_pol = Path(args.politica)
    carpeta = Path(args.evidencia)
    if not ruta_pol.exists() or not carpeta.is_dir():
        print("ERROR: ruta de politica o de evidencia invalida.", file=sys.stderr)
        sys.exit(2)

    hoy = date.fromisoformat(args.hoy) if args.hoy else date.today()

    # TODO 7: carga el YAML (YAML invalido -> codigo 2), llama a evaluar(),
    # imprime un resumen legible, guarda el JSON si se pidio, y termina con
    # el codigo de salida correcto.
    try:
        with ruta_pol.open(encoding="utf-8") as f:
            politica = yaml.safe_load(f)
        if not isinstance(politica, dict):
            raise ValueError("politica.yaml no representa un mapeo valido")
    except Exception as e:
        print(f"ERROR: politica invalida ({e})", file=sys.stderr)
        sys.exit(2)

    resultado = evaluar(politica, carpeta, hoy)

    print(f"Politica v{resultado['politica_version']} -> {resultado['decision']}")
    for c in resultado["controles"]:
        estado = "BLOQUEA" if c["nombre"] in resultado["bloqueantes"] else (
            "excede (informa)" if c["excede"] else "ok"
        )
        print(
            f"  - {c['nombre']:<16} valor={c['valor']} maximo={c['maximo']} "
            f"accion={c['accion']:<8} [{estado}]"
        )
    if resultado["bloqueantes"]:
        print("Bloqueantes: " + ", ".join(resultado["bloqueantes"]))

    if args.json:
        Path(args.json).write_text(
            json.dumps(resultado, indent=2, ensure_ascii=False), encoding="utf-8"
        )

    sys.exit(0 if resultado["decision"] == "AUTORIZADA" else 1)


if __name__ == "__main__":
    main()
