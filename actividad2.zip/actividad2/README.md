# Actividad 2 — Andamio de trabajo

**LSCA2314 · Periodo AD26 · Vale 6 %**

## Qué cambia respecto a la Actividad 1

La Actividad 1 te pidió construir controles que bloquean. Esta te pide algo
distinto: **decidir qué bloquea y qué no, y poder defenderlo.**

Las Notas de Enseñanza lo dicen explícitamente: no se trata de repetir la
implementación técnica, sino de escalar la lógica de control hacia
**gobernanza**.

## La idea central

En la Actividad 1, la decisión estaba escrita dentro del pipeline. Si querías
cambiar un umbral, editabas código.

Aquí la decisión vive en `politica/politica.yaml`, y un motor la aplica. Cambiar
la política **no debe obligar a tocar el motor**. Eso es lo que separa un script
de un sistema de gobernanza.

## Qué se te entrega y qué te toca

| Archivo | Estado | Qué te toca |
|---|---|---|
| `politica/politica.yaml` | ✅ Ejemplo | Ajustar umbrales y **justificar cada uno** |
| `evidencia/` | ✅ Completo | Nada. Reportes de dos ejecuciones reales |
| `verificar.sh` | ✅ Completo | **No lo modifiques.** Es tu autoevaluación |
| `scripts/evaluar_politica.py` | 🔨 Esqueleto | 7 TODO |
| `matriz-quality-gates.csv` | 🔨 Plantilla | Completar y justificar |
| `comparacion-orquestadores.md` | 🔨 Plantilla | Completar |

## Las cuatro reglas que tu motor debe respetar

1. Un control con acción `informa` **nunca** bloquea, aunque exceda su umbral.
2. Un control con acción `bloquea` detiene la entrega si supera su máximo.
3. Las excepciones **vigentes** descuentan hallazgos. Una **caducada** no.
4. Un control sin reporte es un error de la ejecución, no un pase libre.

La tercera es la más interesante: una excepción con fecha de caducidad es una
deuda que se paga sola. Sin fecha, es una excepción permanente disfrazada.

## Cómo saber si vas bien

```bash
./verificar.sh
```

Nueve comprobaciones. Con el andamio recién descargado verás **0 de 9**.

Dos de ellas son las que de verdad importan:

- **"Cambiar la política cambia la decisión"** — si la editas y el resultado no
  cambia, tu motor tiene la lógica escrita dentro y no está leyendo nada.
- **"Una excepción caducada ya no descuenta"** — si sigue descontando, tus
  excepciones son eternas.

> Pasar las nueve **no** es el 100: quedan la matriz, la comparación y el
> documento. Pero fallar alguna sí garantiza perder puntos.

## Requisitos

Python 3.8+ y PyYAML (`pip install pyyaml`). Nada más.
