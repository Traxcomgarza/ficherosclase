# Comparación de orquestadores

## Contexto que asumo

RetailCommerce: equipo de plataforma de ~8 personas hoy, con plan de crecer a
25-30 en 18 meses. Sector retail con datos de tarjeta y de clientes (alcance
PCI-DSS parcial), por lo que auditoría de cambios y control de secretos no son
opcionales. Nadie en el equipo tiene tiempo dedicado exclusivo a operar
infraestructura de CI/CD — el que la administra también escribe features. El
código vive en GitHub.

## Tabla comparativa

| Criterio | Jenkins | GitLab CI | GitHub Actions |
|---|---|---|---|
| Quién opera y actualiza el runner | El equipo: VM/contenedor propio, parches de seguridad, plugins y su compatibilidad entre versiones son responsabilidad interna. Con 8 personas sin rol dedicado, esto compite por tiempo con el roadmap de producto. | Si se usa GitLab.com, runners SaaS gestionados por GitLab; si se usa self-hosted (gitlab-runner), la carga es similar a Jenkins pero con menos superficie de plugins que mantener. | Runners hospedados por GitHub por defecto; self-hosted opcional solo si se necesita hardware o red específica. Cero mantenimiento de la capa base para el caso típico. |
| Dónde viven los secretos y quién los ve | Credentials Store de Jenkins (o vault externo integrado). El acceso está atado a quién administra el propio Jenkins — si hay una brecha en el servidor, los secretos están en el mismo blast radius. | GitLab CI/CD Variables por proyecto/grupo, con scoping por entorno y opción de "masked" y "protected" (solo ramas/tags protegidos las ven). | GitHub Actions Secrets por repo/organización/entorno, con aprobación requerida para exponer secretos de "environment" en PRs de forks — relevante si algún día se acepta código externo. |
| Cómo se audita quién cambió el pipeline | El Jenkinsfile vive en el repo (bien), pero la configuración del propio servidor (plugins, credenciales, jobs no declarativos) puede cambiarse desde la UI sin dejar rastro en git. Auditoría depende de que el equipo sea disciplinado. | Todo el pipeline es `.gitlab-ci.yml` versionado; los cambios a variables/protecciones quedan en el audit log de GitLab (Premium para el detalle fino). | Todo es YAML versionado en `.github/workflows`; cambios a secrets/environments quedan en el audit log de la organización. Revisión de pipeline se hace vía PR igual que código de producto. |
| Qué pasa al crecer de 3 a 30 personas | Escala mal sin inversión: sin un encargado dedicado, los plugins se desactualizan, los jobs se vuelven snowflakes configurados a mano, y el "quién puede tocar el servidor" se vuelve un problema de acceso ad-hoc. | Escala bien si ya se usa GitLab para todo (issues, MRs, CI en un solo lugar); el costo es adoptar una plataforma completa, no solo un CI. | Escala bien de forma natural porque ya se usa GitHub para el código: los mismos permisos de repo/equipo controlan quién toca el pipeline, sin plataforma adicional que aprender. |

## Decisión y defensa

Para RetailCommerce elijo **GitHub Actions**. El código ya vive en GitHub, así
que no se añade una plataforma nueva que administrar ni se duplican permisos:
los mismos equipos y ramas protegidas que ya existen gobiernan quién puede
tocar el pipeline. Con un equipo pequeño y sin rol dedicado a operar
infraestructura de CI, no tener que mantener un runner propio (Jenkins) pesa
más que la flexibilidad que Jenkins ofrecería. Y frente a GitLab CI, adoptarlo
implicaría migrar repos e issues a otra plataforma solo para ganar un CI que,
en la práctica, ya viene incluido donde está el código.

**En qué escenario esta elección sería la equivocada:** si RetailCommerce
tuviera que ejecutar builds en hardware específico on-premise (por ejemplo,
pruebas contra un dispositivo físico en un almacén, o requisitos regulatorios
de que el código nunca salga de una red controlada por la empresa), depender
de runners hospedados por GitHub dejaría de ser viable, y ahí Jenkins
self-hosted — con todo el costo de mantenerlo — sería la opción correcta pese
a la carga operativa.
