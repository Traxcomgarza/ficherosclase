#!/usr/bin/env bash
# verificar.sh — SE TE ENTREGA TERMINADO. No lo modifiques.
#
# Comprueba que tu motor de politica cumple el contrato de la Actividad 2.
# Uso: ./verificar.sh

set -uo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
MOTOR="$ROOT/scripts/evaluar_politica.py"
POL="$ROOT/politica/politica.yaml"
OK=0; FAIL=0

check() {
  if [ "$2" = "$3" ]; then printf "  [ OK ]  %-50s %s\n" "$1" "$3"; OK=$((OK+1))
  else printf "  [FALLA] %-50s esperado=%s obtenido=%s\n" "$1" "$2" "$3"; FAIL=$((FAIL+1)); fi
}

cat > "$ROOT/.contrato.py" <<'PYEOF'
import json, sys
req = set(sys.argv[1].split(","))
try: d = json.load(sys.stdin)
except Exception: print("json-invalido"); sys.exit(0)
if not isinstance(d, dict): print("json-invalido"); sys.exit(0)
faltan = req - set(d)
print("ok" if not faltan else "faltan:" + ",".join(sorted(faltan)))
PYEOF

LLAVES="decision,politica_version,controles,bloqueantes"

# Ejecuta el motor y devuelve el codigo de salida
salida() { python3 "$MOTOR" "$POL" "$1" ${2:-} >/dev/null 2>&1; echo $?; }

# Ejecuta y valida el JSON del contrato
contrato() {
  local esperado="$1"; local carpeta="$2"; shift 2
  local rep; rep="$(mktemp)"
  python3 "$MOTOR" "$POL" "$carpeta" --json "$rep" "$@" >/dev/null 2>&1
  local cod=$?
  if [ "$cod" != "$esperado" ]; then rm -f "$rep"; echo "salida=$cod"; return; fi
  if [ ! -s "$rep" ]; then rm -f "$rep"; echo "sin-json"; return; fi
  python3 "$ROOT/.contrato.py" "$LLAVES" < "$rep"; rm -f "$rep"
}

contrato_pol() {  # esperado, politica, carpeta, [extra...]
  local esperado="$1"; local pol="$2"; local carpeta="$3"; shift 3
  local rep; rep="$(mktemp)"
  python3 "$MOTOR" "$pol" "$carpeta" --json "$rep" "$@" >/dev/null 2>&1
  local cod=$?
  if [ "$cod" != "$esperado" ]; then rm -f "$rep"; echo "salida=$cod"; return; fi
  if [ ! -s "$rep" ]; then rm -f "$rep"; echo "sin-json"; return; fi
  python3 "$ROOT/.contrato.py" "$LLAVES" < "$rep"; rm -f "$rep"
}

campo() { python3 -c "import json,sys;print(json.load(open(sys.argv[1])).get(sys.argv[2],'?'))" "$1" "$2" 2>/dev/null || echo '?'; }

echo "==========================================================="
echo " Verificacion de la Actividad 2 - LSCA2314"
echo "==========================================================="
echo
echo "--- Decision sobre evidencia real ---"
check "Bloquea la ejecucion con hallazgos criticos" "ok" \
  "$(contrato 1 "$ROOT/evidencia/ejecucion-bloqueada")"
check "Autoriza la ejecucion limpia" "ok" \
  "$(contrato 0 "$ROOT/evidencia/ejecucion-autorizada")"

echo
echo "--- La politica manda, no el codigo ---"
TMP="$(mktemp -d)"; cp -r "$ROOT/politica/politica.yaml" "$TMP/pol.yaml"
# Un control que solo informa no debe bloquear aunque se exceda
python3 - "$TMP/pol.yaml" <<'PYEOF'
import sys, yaml
p = sys.argv[1]; d = yaml.safe_load(open(p))
d["controles"]["codigo_medio"]["maximo"] = 0      # se excede
d["controles"]["codigo_medio"]["accion"] = "informa"
yaml.safe_dump(d, open(p, "w"), allow_unicode=True)
PYEOF
python3 "$MOTOR" "$TMP/pol.yaml" "$ROOT/evidencia/ejecucion-autorizada" >/dev/null 2>&1
check "Un control que solo informa nunca bloquea" "0" "$?"

# El mismo control, ahora bloqueando, si debe detener
python3 - "$TMP/pol.yaml" <<'PYEOF'
import sys, yaml
p = sys.argv[1]; d = yaml.safe_load(open(p))
d["controles"]["codigo_medio"]["accion"] = "bloquea"
d["excepciones"] = []          # sin excepciones: aisla el efecto de la politica
yaml.safe_dump(d, open(p, "w"), allow_unicode=True)
PYEOF
check "Cambiar la politica cambia la decision" "ok" \
  "$(contrato_pol 1 "$TMP/pol.yaml" "$ROOT/evidencia/ejecucion-autorizada")"
rm -rf "$TMP"

echo
echo "--- Excepciones con caducidad ---"
T2="$(mktemp -d)"; cp "$ROOT/politica/politica.yaml" "$T2/pol.yaml"
python3 - "$T2/pol.yaml" <<'PYEOF'
import sys, yaml
p = sys.argv[1]; d = yaml.safe_load(open(p))
d["controles"]["codigo_medio"]["maximo"] = 0
d["controles"]["codigo_medio"]["accion"] = "bloquea"
d["excepciones"] = [{"control":"codigo_medio","identificador":"B108",
                     "motivo":"prueba","responsable":"x","caduca":"2026-12-31"}]
yaml.safe_dump(d, open(p,"w"), allow_unicode=True)
PYEOF
python3 "$MOTOR" "$T2/pol.yaml" "$ROOT/evidencia/ejecucion-autorizada" --hoy 2026-09-01 >/dev/null 2>&1
check "Una excepcion vigente descuenta el hallazgo" "0" "$?"
check "Una excepcion caducada ya no descuenta" "ok" \
  "$(contrato_pol 1 "$T2/pol.yaml" "$ROOT/evidencia/ejecucion-autorizada" --hoy 2027-01-15)"
rm -rf "$T2"

echo
echo "--- Manejo de errores ---"
T3="$(mktemp -d)"; printf 'controles: [\n  esto: no es yaml valido\n' > "$T3/roto.yaml"
python3 "$MOTOR" "$T3/roto.yaml" "$ROOT/evidencia/ejecucion-autorizada" >/dev/null 2>&1
check "Un YAML invalido termina con codigo 2" "2" "$?"
rm -rf "$T3"

REP="$(mktemp)"
python3 "$MOTOR" "$POL" "$ROOT/evidencia/ejecucion-bloqueada" --json "$REP" >/dev/null 2>&1
if [ -s "$REP" ]; then
  D="$(campo "$REP" decision)"
  check "El JSON declara la decision como BLOQUEADA" "BLOQUEADA" "$D"
  N="$(python3 -c "import json;print(len(json.load(open('$REP')).get('bloqueantes',[])))" 2>/dev/null || echo '?')"
  check "Lista al menos un control bloqueante" "si" "$([ "$N" != "0" ] && [ "$N" != "?" ] && echo si || echo no)"
else
  check "El JSON declara la decision como BLOQUEADA" "BLOQUEADA" "sin-json"
  check "Lista al menos un control bloqueante" "si" "sin-json"
fi
rm -f "$REP" "$ROOT/.contrato.py"

echo
echo "==========================================================="
printf " Resultado: %d aprobadas, %d fallidas\n" "$OK" "$FAIL"
echo "==========================================================="
[ "$FAIL" -eq 0 ] && { echo " Tu motor de politica cumple el contrato."; exit 0; }
echo " Revisa las lineas marcadas [FALLA] antes de entregar."
exit 1
