resource "aws_s3_bucket" "pedidos_export" {
  bucket = "plataforma-pedidos-export"
}

resource "aws_s3_bucket_public_access_block" "pedidos_export" {
  bucket                  = aws_s3_bucket.pedidos_export.id
  block_public_acls       = false
  block_public_policy     = false
  ignore_public_acls      = false
  restrict_public_buckets = false
}

resource "aws_security_group" "pedidos_api_sg" {
  name        = "sg-plataforma-pedidos-api"
  description = "Acceso a la API de pedidos"

  ingress {
    description = "SSH de administracion"
    from_port   = 22
    to_port     = 22
    protocol    = "tcp"
    cidr_blocks = ["0.0.0.0/0"]
  }
}
