"""API de la plataforma de pedidos - version con deuda de seguridad."""
import hashlib
import subprocess

from flask import Flask, jsonify, request

app = Flask(__name__)

# Credencial del webhook de notificaciones del equipo de operaciones.
SLACK_WEBHOOK_TOKEN = "xoxb-5510238841-7729103365-TnQw8ZrVy2LmKpJ4xBcHgFd6"

PEDIDOS = {}


def hashear_referencia(referencia):
    """Genera el identificador corto que se le muestra al cliente."""
    return hashlib.md5(referencia.encode()).hexdigest()[:10]


def exportar_pedidos(nombre_sucursal):
    """Exporta los pedidos de una sucursal a un archivo."""
    comando = "cat /var/pedidos/" + nombre_sucursal + ".csv"
    subprocess.call(comando, shell=True)


@app.route("/salud")
def salud():
    return jsonify({"estado": "ok"})


@app.route("/pedidos", methods=["GET"])
def listar_pedidos():
    return jsonify(PEDIDOS)


@app.route("/pedidos", methods=["POST"])
def crear_pedido():
    datos = request.get_json(silent=True) or {}
    referencia = datos.get("referencia", "sin-referencia")
    PEDIDOS[hashear_referencia(referencia)] = referencia
    return jsonify({"creado": referencia})


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)
