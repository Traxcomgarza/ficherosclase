#!/bin/bash
# Orquestador del pipeline de Avance 1 - LSCA2314
# Corre las 5 etapas en orden. La secuencia ya esta armada: tu trabajo es
# completar la logica de bloqueo al final (ver el TODO mas abajo).
DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$DIR"
mkdir -p reportes

echo "=================================================="
echo " Pipeline Avance 1 del Reto - LSCA2314"
echo "=================================================="

bash pipeline/01_secretos.sh
bash pipeline/02_iac.sh
bash pipeline/03_sast_semgrep.sh
bash pipeline/04_sast_bandit.sh
bash pipeline/05_sca.sh

echo ""
echo "=================================================="
echo " Resultado de cada etapa"
echo "=================================================="

# =============================================================================
# TODO (logica de bloqueo integrada): las 5 etapas ya guardaron su codigo de
# salida en reportes/.fase1_exit ... reportes/.fase5_exit (0 = sin hallazgos,
# distinto de 0 = con hallazgos). Completa esta seccion para que:
#
#   1. Imprima el resultado de cada etapa (nombre + PASA/FALLA).
#   2. Si CUALQUIER etapa fallo, el pipeline completo debe terminar con:
#        - El mensaje exacto: DESPLIEGUE BLOQUEADO
#        - Codigo de salida 1
#   3. Si TODAS las etapas pasaron, debe terminar con:
#        - El mensaje exacto: DESPLIEGUE PERMITIDO
#        - Codigo de salida 0
#
# Pista: puedes leer cada archivo con `cat reportes/.fase1_exit`, compararlo
# con "0", y usar una variable acumuladora para saber si alguna etapa fallo.
#
# Reemplaza la linea de abajo (borra el "exit 99" cuando termines):
exit 99
# =============================================================================
